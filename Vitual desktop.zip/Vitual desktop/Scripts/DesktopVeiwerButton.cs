using UnityEngine;

public class DesktopVeiwerButton : MonoBehaviour
{
    public VrMouseController vrMouseController; // componant in parent object  
    public void SetWindowOnTop()
    {
        vrMouseController.ActivateWindow(); //bring window to front and activate
        vrMouseController.DesktopVeiw(); // refresh window
    }
    public void NotMainWindow()
    {
        vrMouseController.isDesktop = false;// this is a view background window dont show keyboard or allow mouse control
    }
}
