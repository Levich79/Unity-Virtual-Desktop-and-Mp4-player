using System.Collections;
using TMPro;
using System.Runtime.InteropServices;
using UnityEngine;
using System;
using uWindowCapture;

public class VrMouseController : MonoBehaviour
{
    public TextMeshProUGUI panelText;
    public GameObject sidePanel;// side panel/s
    public GameObject keyboard; // keyboard used with this object
    public bool isDesktop = true;// is this window active or veiw only 
    private UwcWindowTexture windowTextuRe; //windowTex on this object;
    public Vector2 newCursorPos; // laserPointer hit
    private float minScreenX, maxScreenx, minScreenY, maxScreeny;  // window screen bounds//////////////////////
    public float minX, maxX, minY, maxY; //canvas bounds   
    private float currentCursorX, cureentCusrorY; // current pos of pointer on canvas   
    private float yPercent, xPercent; // % of cursor postion from 
    private float totalXdis, totalYdi; // total distance of canvas
    private float totalScreenx, totalScreenY; // total distance of current window
    public Transform cursor; // mouse follows this 
    private float storedYpos; // store to ensure cursor doesnt leave canvas
    public bool onPage = false; // is laser pointer on the canvas

    #region Microsoft Windows
    
    [Flags]
    public enum MouseEventFlags
    {
        LeftDown = 0x00000002,
        LeftUp = 0x00000004,
        MiddleDown = 0x00000020,
        MiddleUp = 0x00000040,
        Move = 0x00000001,
        Absolute = 0x00008000,
        RightDown = 0x00000008,
        RightUp = 0x00000010
    }

    [DllImport("user32.dll", EntryPoint = "SetCursorPos")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetCursorPos(int X, int Y);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetCursorPos(out MousePoint lpMousePoint);

    [DllImport("user32.dll")]
    private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

    public static void SetCursorPosition(int X, int Y)
    {
        SetCursorPos(X, Y);
    }

    public static void SetCursorPosition(MousePoint point)
    {
        SetCursorPos(point.X, point.Y);
    }

    public static MousePoint GetCursorPosition()
    {
        MousePoint currentMousePoint;
        var gotPoint = GetCursorPos(out currentMousePoint);
        if (!gotPoint) { currentMousePoint = new MousePoint(0, 0); }
        return currentMousePoint;
    }

    public static void MouseEvent(MouseEventFlags value)
    {
        MousePoint position = GetCursorPosition();

        mouse_event
            ((int)value,
            position.X,
             position.Y,
             0,
             0)
             ;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MousePoint
    {
        public int X;
        public int Y;

        public MousePoint(int x, int y)
        {
            X = x;
            Y = y;
        }

    }

    [DllImport("USER32.DLL")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("User32.dll")]
    private static extern bool ShowWindow(IntPtr handle, int nCmdShow);
    private const int SW_SHOWMAXIMIZED = 3;
    #endregion
    public static void BringToFront(IntPtr handle)//set window to max size and to the front (can change(int)"SW_SHOWMAXIMIZED" for show mormal or min)
    {     
        if (handle == IntPtr.Zero)
            return;
        // Maximize window
        ShowWindow(handle, SW_SHOWMAXIMIZED);

        SetForegroundWindow(handle);
    }  
    void Start()
    {
        windowTextuRe = GetComponent<UwcWindowTexture>(); // get windowTex component
        minScreenX = 0; // will always be 0
        minScreenY = 0; // will always be 0
        maxScreenx = Screen.width; // at start set to connected moniter resolution
        maxScreeny = Screen.height; // at start set to connected moniter resolution      
        storedYpos = cursor.localPosition.z; // storing pos of cursor as vector2    
    }
    private void FixedUpdate()
    {
        if (onPage) // laser is on canvas
        {
           if(isDesktop) // active window
           {
              keyboard.SetActive(true); //show keyboard because this is the active desktop window

              SetCursorPos((int)newCursorPos.x, (int)newCursorPos.y); // Mouse follow cursor obj
           }
           if(!isDesktop) // not active window (open but in background)
           {
              keyboard.SetActive(false); // close keyboard because this is veiw only window
           }
        }
        if (!onPage && !isDesktop) // laser in not on the canvaand we are veiwing a background window
        {
            keyboard.SetActive(false); // close keyboard because this is veiw only window
        }

    }
    void Update()
    {
       
        if(windowTextuRe.window!= null) //adjusts to window size
        {
            maxScreenx = windowTextuRe.window.width;
            maxScreeny = windowTextuRe.window.height;

        }
        
        if (cursor.localPosition.x < maxX)//prevent cursor from leaving canvas
        {
            cursor.localPosition = new Vector3(maxX, cursor.localPosition.y, storedYpos);

        }
        if (cursor.localPosition.y > maxY)//prevent cursor from leaving canvas
        {
            cursor.localPosition = new Vector3(cursor.localPosition.x,maxY, storedYpos);
        }
        if (cursor.localPosition.x > minX)//prevent cursor from leaving canvas
        {
            cursor.localPosition = new Vector3(minX, cursor.localPosition.y, storedYpos);
        }
        if (cursor.localPosition.y < minY)//prevent cursor from leaving canvas
        {
            cursor.localPosition = new Vector3(cursor.localPosition.x, minY,storedYpos);
        }
       
        //total canvas  dist
        totalXdis = maxX - minX;
        totalYdi = maxY - minY;

        //position of cursor vector2
        currentCursorX = cursor.localPosition.x;
        cureentCusrorY = cursor.localPosition.y;

        // find % of cursor.x realtive to canvas
        float  h = currentCursorX + maxX;   
        float  v = h /totalXdis;
        xPercent = v * 100;  // z is % 

        // find % of cursor.y realtive to canvas
        float i = cureentCusrorY + maxY;   
        float j = i / totalYdi;
        yPercent = j * 100; // j is %

        //total screen dist
        totalScreenx = maxScreenx - minScreenX;
        totalScreenY = maxScreeny - minScreenY;

        // apply % value to screen
        float l = totalScreenx - (totalScreenx * xPercent / 100);
        float m = totalScreenY - (totalScreenY * yPercent / 100);

        //mouse pos = pointer
        newCursorPos = new Vector2(l, m);

    }
    public void ActivateWindow() // activates chosen window and brings it to front
    {
        IntPtr p = windowTextuRe.window.handle;
        BringToFront(p);
    }
    public void MouseClickDown()
    {
        if(onPage)
        {
            if(isDesktop)
            {
                MouseEvent(MouseEventFlags.LeftDown);
                System.Threading.Thread.Sleep(100);
                MouseEvent(MouseEventFlags.LeftUp);
            }
           
        }
       



    }// simulate mouse click if laser is on canvas
    public void MouseClickHold()// simulate mouse hold if laser is on canvas !!!! If you call t his you must call MouseClickUp() after !!!!
    {
        MouseEvent(MouseEventFlags.LeftDown);
    }
    public void MouseClickUp()// simulate mouse up if laser is on canvas. 
    {
        MouseEvent(MouseEventFlags.LeftUp);
        


    }
    public void DesktopVeiw() // refresh the window on change
    {
        StartCoroutine(ShowDesktop());
    }
    public IEnumerator ShowDesktop()
    {
               
        yield return new WaitForSeconds(0.01f);
        windowTextuRe.shouldUpdateWindow = true;
        windowTextuRe.type_ = 0;
        yield return new WaitForSeconds(0.01f);
        windowTextuRe.shouldUpdateWindow = true;
        windowTextuRe.type_ = (WindowTextureType)1;
        isDesktop = true;
        
        StopCoroutine(ShowDesktop());
    }     
    public void MenuCloser()
    {
        if(sidePanel.activeInHierarchy)
        {
            sidePanel.SetActive(false);
            panelText.text = "Show Panels";
        }
        else
        {
            sidePanel.SetActive(true);
            panelText.text = "Hide Panels";
        }
    }
}
