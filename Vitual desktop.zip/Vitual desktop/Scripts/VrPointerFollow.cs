
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class VrPointerFollow : MonoBehaviour
{	
	private GameObject cursor;//cusror on the canvas
	private VrMouseController vrMouseController;// from canvas object
	private VideoPlayerManger videoPlayer; //from video sceen
	private ActionBasedController actionBasedController; // hand this is attached to 
	private bool onScreen; // is laser on canvas

    private void Start()
    {
		actionBasedController = gameObject.GetComponentInParent<ActionBasedController>();
    }
    void Update()
	{
		if(onScreen) //we are on the canvas
        {
			bool pressed;
			if(actionBasedController != null)
            {
				InteractionState s = actionBasedController.activateInteractionState;// if this hand trigger is pressed
				pressed = s.activatedThisFrame;

				if (pressed) // trigger is pressed
				{
					MouseClick();// simulate mouse click down/up
				}
			}
			else
            {
				Debug.LogWarning(" Add Controller to VrPointerFollow in inspector ");
            }


			
		}		
	}
    private void FixedUpdate()
    {
		Vector3 fwd = transform.TransformDirection(Vector3.forward); // direction of raycast travel
		ShootLaserFromTargetPosition(transform.position, fwd, 100); // scan for canvas
					
	}
	void ShootLaserFromTargetPosition(Vector3 targetPosition, Vector3 direction, float length)// scan for canvas
	{
		Ray ray = new Ray(targetPosition, direction);
		RaycastHit raycastHit;
		

		if (Physics.Raycast(ray, out raycastHit, length))
		{
					
			if (raycastHit.collider.gameObject.GetComponent<VrMouseController>() != null) // ray is on the  canvas
			{
												
				if(cursor != null)
                {
					cursor.transform.position = raycastHit.point; // move cursor to the ray 
				}				
			}
		}			
	}
	public void MouseClick()
    {
		if(vrMouseController!=null && vrMouseController.onPage)// make sure we are on the canvas and have found controller component
        {
			vrMouseController.MouseClickDown(); // simulate mouse click	
		}		
	}


    private void OnTriggerEnter(Collider other)
    {
		if(other.gameObject.GetComponent<VideoPlayerManger>() != null)
        {
			videoPlayer = other.gameObject.GetComponent<VideoPlayerManger>();			
		    if (videoPlayer.isVideoPlayerActive)
			{
			  videoPlayer.VideoOptions(true); //show video options
            }
        }
        if(other.gameObject.GetComponent<VrMouseController>() != null)
        {
		    vrMouseController = other.GetComponent<VrMouseController>();
			cursor = vrMouseController.cursor.gameObject; // get ref to cursor attached to the canvas
			onScreen = true; // know we are on canvas to allow mouse click
		    vrMouseController.onPage = true; //we are on screen so allow control of the mouse
		}
    }
    private void OnTriggerExit(Collider other)
    {
		if (other.gameObject.GetComponent<VideoPlayerManger>() != null)
		{
			if (videoPlayer != null && videoPlayer.isVideoPlayerActive)
			{
				videoPlayer.VideoOptions(false);//hide video options
				videoPlayer = null;
			}
		
		}
		if (other.gameObject.GetComponent<VrMouseController>() != null)
		{
			if (vrMouseController != null)
			{
				onScreen = false;// we are not on screen so dont allow mouse clicks
				vrMouseController.onPage = false; // we are not on screen so dont allow mouse control
				cursor = null;
				vrMouseController = null;
			}
		}

		
	}
}