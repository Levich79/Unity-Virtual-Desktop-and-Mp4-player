using System.Collections;
using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;

public class VideoPlayerManger : MonoBehaviour
{
    public bool isVideoPlayerActive; // check if video player is active
    public VideoPlayer videoPlayer;       
    public string[] items; //mp4 files if any are found
    public TextMeshProUGUI tex; //video name
    public TextMeshProUGUI videoCount; //number of videos
    public GameObject[] playButtons; // buttons used to play/pause/skip/volume
    public GameObject[] startMenu; //vidoes player starting menu
    public GameObject[] mainMenuItems; // menu for video/desktop
    public GameObject[] startPlayOptions;
    public GameObject desktop; //desktop 
    public double videoTime; //current video time
    public int count = 0; // current video count
    public Slider slider; //slider used to change video time

    public bool pressed = false;// know if we are adjusting the time slider  
    void Start()
    {       
        LoadFiles();//search for videos
    }
    public void FixedUpdate()
    {
        if(videoPlayer.isPlaying) // check if video is playing
        {
            float a = (float)videoPlayer.length - 1; // total time of playing video

            if (videoPlayer.time >= a ) // if video has ended
            {
                StartCoroutine(PlayNextVideo()); //plays next wideo 
            }
                videoTime = videoPlayer.time; // get current time of video being played
            if(slider.maxValue <=1)
            {
                slider.maxValue = (float)videoPlayer.length; //set slider max to video legnth
            }
            if(!pressed) // we are not adjusting the slider
            {                               
                    slider.value = (float)videoPlayer.time; // make slider follow current time of video                          
            }
                      
        }       
    }
    public void OpenVideoFolder()
    {
        Application.OpenURL("file:///" + Application.dataPath + "/Videos"); //opens folder on desktop  !! Folder WILL NOT carry over to build so create a new folder named "Videos" and place in the data folder after build!!
    }
    public void LoadFiles()
    {
        if (Directory.Exists(Application.dataPath + "/Videos"))// search for folder in game data folder 
        {
           
            items = Directory.GetFiles(Application.dataPath + "/Videos", "*mp4"); // add found videos to array
           
            if(items.Length>0) // if videos exist
            {
                string name = Path.GetFileName(items[count]); // gets name of  first video
                tex.text = name.Replace(".mp4", "").Trim(); // remove the .mp4 from end of file name and shoe video name
            }
                        
            Debug.Log("Folder Found");
        }
        else // folder does not exist or is in another path
        {
            Debug.Log("Folder not Found");

            tex.text = "Video Folder Not Found"; //show text stating the folder is missing
          
        }

        if(items.Length >0)
        {
            videoCount.text = items.Length + " Videos Found"; // show how many video files are in folder
        }
        if(items.Length == 0)
        {
            videoCount.text = "Folder Empty"; // warn there are no video files are in folder
        }
    }
    public void Next() // show the next video button on main video menu 
    {
        videoCount.text = ""; // remove number of videos found text
      
        if (count < items.Length - 1) // if there is another video after current one
        {
            count = count + 1; // get count for next video

            string name = Path.GetFileName(items[count]); // get name of next video
              tex.text = name.Replace(".mp4", "").Trim(); // remove .mp4 from file name and show video name
        
        }
        else // this is the only video or the last one in the array
        {

            count = 0; // reset count to the first video
            string name = Path.GetFileName(items[count]); // get name of next video
            tex.text = name.Replace(".mp4", "").Trim(); // remove .mp4 from file name and show video name

        }

    }
    public void Prev() // show the previous video button on main video menu 
    {
        videoCount.text = ""; // remove number of videos found text

        if (count > 0) // if there are more than 1 video and current video isnt the first
        {

            count = count - 1; // get count for the previous video in the array
            string name = Path.GetFileName(items[count]); //get name of previous video
             tex.text = name.Replace(".mp4", "").Trim(); //remove.mp4 from file name and show video name

        }
        else
        {

            count = items.Length - 1;
            string name = Path.GetFileName(items[count]); //get name of video
            tex.text = name.Replace(".mp4", "").Trim();//remove.mp4 from file name and show video name

        }

    }
    public void PlayVideo() // play button
    {
         
        if(!videoPlayer.isPlaying && !videoPlayer.isPaused) // check if it isnt paused or already playing
        {
            string videoName = Path.GetFileName(items[count]); // name of current video

            slider.maxValue = 1;
            videoPlayer.url = Application.dataPath + "/Videos/" + videoName; // add path to video file to player
            videoPlayer.Play(); // play the video
            return;
        }
        if(!videoPlayer.isPaused && videoPlayer.isPlaying) // if video is playing and its not paused
        {
            videoPlayer.Pause(); // pause the video
            videoPlayer.time = videoTime; // get current video time
            return;
        }
        if(videoPlayer.isPaused) // if video is paused 
        {
            videoPlayer.Play(); // unpause and play
            videoPlayer.time = videoTime; // get current video time
            return;
        }
        
    }
    public void PausePlayer() // pause button
    {
        videoPlayer.Pause();//pause video
    } 
    public void VideoTime(float tyme) // set video time if we are using slider to adjust
    {
        if(pressed)
        {
            videoPlayer.time = tyme;
            videoTime = tyme;
            
        }

    }
    public void Press()// slider being used
    {
        pressed = true;

    }
    public void NotPressed()// slider not in use
    {
        pressed = false;
        
    }
    public IEnumerator PlayNextVideo() // used to auto play next video when current one ends or replay if only one exist
    {
        videoPlayer.Stop(); //stop current video
        yield return new WaitForSeconds(0.1f);
        Next(); // load next video
        yield return new WaitForSeconds(0.1f);
        PlayVideo(); // play next video
        StopCoroutine(PlayNextVideo());
    }
    public void PlayNext() // play next video
    {

         videoCount.text = ""; // remove number of videos found text 

       
        if (count < items.Length - 1) 
        {

            count = count + 1;

            string name = Path.GetFileName(items[count]);
              tex.text = name.Replace(".mp4", "").Trim();
            
        }
        else
        {

            count = 0;
            string name = Path.GetFileName(items[count]);
            tex.text = name.Replace(".mp4", "").Trim();
            
        }
       
            string videoName = Path.GetFileName(items[count]);

            slider.maxValue = 1;
            videoPlayer.url = Application.dataPath + "/Videos/" + videoName;
            videoPlayer.Play();

    }
    public void PlayPrev() // play previous video
    {
         videoCount.text = "";      

        if (count > 0)
        {

            count = count - 1;
            string name = Path.GetFileName(items[count]);
             tex.text = name.Replace(".mp4", "").Trim();
            
        }
        else
        {

            count = items.Length - 1;
            string name = Path.GetFileName(items[count]);
             tex.text = name.Replace(".mp4", "").Trim();
         
        }

        string videoName = Path.GetFileName(items[count]);

        slider.maxValue = 1;
        videoPlayer.url = Application.dataPath + "/Videos/" + videoName;
        videoPlayer.Play();

    }
    public void VolumeControl(float b) // control the video volume via slider
    {
        gameObject.GetComponent<AudioSource>().volume = b;
    }
    public void StartShow()// start video player while activating the video player buttons and close the main video player menu options
    {
        isVideoPlayerActive = true;
        foreach(GameObject ob in playButtons)
        {
            ob.SetActive(true);
        }
        foreach(GameObject obj in startMenu)
        {
            obj.SetActive(false);
        }

        PlayVideo();

    }
    public void StopShow()// return to main video menu while deactivating the player buttons and activating the main video menu
    {
        isVideoPlayerActive = false;
        videoPlayer.Stop();
        foreach (GameObject ob in playButtons)
        {
            ob.SetActive(false);
        }
        foreach (GameObject obj in startMenu)
        {
            obj.SetActive(true);
        }

    }
    public void MainMenu()// return to main menu and stop video if one is playing
    {
        foreach (GameObject ob in playButtons)
        {
            ob.SetActive(false);
        }
        foreach (GameObject obj in startMenu)
        {
            obj.SetActive(false);
        }
        desktop.SetActive(false);

        foreach(GameObject g in mainMenuItems)
        {
            g.SetActive(true);
        }

        if(videoPlayer.isPlaying)
        {
            videoPlayer.Stop();
        }
        
    }
    public void VideoPlayer() // hide menu and show videoplayer
    {
        LoadFiles(); // search for videos
        foreach (GameObject g in mainMenuItems)
        {
            g.SetActive(false);
        }
        foreach (GameObject obj in startMenu)
        {
            obj.SetActive(true);
        }
        if (items.Length == 0) // if there are no files dont show play options
        {
            foreach (GameObject ob in startPlayOptions)
            {
                ob.SetActive(false);
            }

        }      
    }
    public void Desktop() // hide menu and open desktop
    {
        foreach (GameObject g in mainMenuItems)
        {
            g.SetActive(false);
        }
        desktop.SetActive(true);
    }
    public void VideoOptions(bool g)// show/hide video play options
    {
        if(isVideoPlayerActive)
        {
            foreach (GameObject ob in playButtons)
            {
                ob.SetActive(g);
            }
        }
        else
        {
            foreach (GameObject ob in playButtons)
            {
                ob.SetActive(false);
            }
        }
       

    }
}
