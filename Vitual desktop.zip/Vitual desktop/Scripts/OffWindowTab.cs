using UnityEngine;
using uWindowCapture;

public class OffWindowTab : MonoBehaviour
{
    public void InitializeWindow()// Main window
    {

        foreach (Transform t in transform.parent) // find others in parent
        {
            if(t.GetComponent<UwcWindowListItem>()!= null) // if they are window items
            {
                if (t != this) // if not this
                {
                    UwcWindowListItem listItem = t.GetComponent<UwcWindowListItem>(); // get window component

                    if (listItem.windowTexture != null) // window was active
                    {
                        listItem.RemoveWindow(); //  remove window
                    }

                }
            }
          

            if(t.GetComponent<DesktopVeiwerButton>()!= null)
            {
                t.GetComponent<DesktopVeiwerButton>().SetWindowOnTop(); // we want this window to be up front and active
            }
        }


    }
    public void NotMain() // viewed window
    {
        foreach (Transform t in transform.parent) // find others in parent
        {
            if (t.GetComponent<UwcWindowListItem>() != null) // if they are window items
            {
                if (t != this) // if not this
                {
                    UwcWindowListItem listItem = t.GetComponent<UwcWindowListItem>(); // get window component

                    if (listItem.windowTexture != null) // if the window was active
                    {
                        listItem.RemoveWindow(); // remove window
                    }

                }
            }


            if (t.GetComponent<DesktopVeiwerButton>() != null)
            {
                t.GetComponent<DesktopVeiwerButton>().NotMainWindow(); // we want to view this window
            }
        }
    }
}
